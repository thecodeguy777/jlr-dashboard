<template>
  <div class="space-y-6">
    <h2 class="text-xl font-bold">Weekly Summary</h2>

    <!-- Bar Chart: Deliveries per Day -->
    <div class="bg-white rounded-xl shadow p-4">
      <h3 class="text-md font-semibold mb-2">Deliveries per Day</h3>
      <BarChart :data="dailyStats" xKey="date" yKey="deliveries" />
    </div>

    <!-- Performance Table -->
    <div class="bg-white rounded-xl shadow p-4">
      <h3 class="text-md font-semibold mb-2">Worker Performance</h3>
      <table class="w-full text-sm">
        <thead>
          <tr class="text-left border-b">
            <th class="py-2">Worker</th>
            <th class="py-2">Deliveries</th>
            <th class="py-2">Avg. Completion Time</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(worker, index) in weeklyWorkers" :key="index" class="border-b">
            <td class="py-2">{{ worker.name }}</td>
            <td class="py-2">{{ worker.deliveries }}</td>
            <td class="py-2">{{ worker.avgTime }}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Clickable Days -->
    <div class="bg-white rounded-xl shadow p-4">
      <h3 class="text-md font-semibold mb-2">Select a Day</h3>
      <ul class="flex flex-wrap gap-4">
        <li
          v-for="day in dailyStats"
          :key="day.date"
          class="cursor-pointer text-blue-500 hover:underline"
          @click="$emit('selectDate', day.date)"
        >
          {{ day.date }}
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import BarChart from '@/components/BarChart.vue'

const props = defineProps({
  dailyStats: Array
})

const weeklyWorkers = computed(() => {
  const summary = {}

  props.dailyStats.forEach(day => {
    day.workers?.forEach(worker => {
      if (!summary[worker.name]) {
        summary[worker.name] = { name: worker.name, deliveries: 0, times: [] }
      }
      summary[worker.name].deliveries += worker.deliveries
      summary[worker.name].times.push(worker.avgTime)
    })
  })

  return Object.values(summary).map(worker => {
    const avgTime = worker.times.length
      ? (worker.times.reduce((a, b) => a + b, 0) / worker.times.length).toFixed(2) + ' mins'
      : 'N/A'
    return { ...worker, avgTime }
  })
})
</script>