<template>
  <div class="p-6">
    <!-- Breadcrumb -->
    <div class="text-sm text-gray-600 mb-4">
      <span @click="setLevel('monthly')" class="cursor-pointer hover:underline">Monthly</span>
      <span v-if="currentLevel !== 'monthly'"> > </span>
      <span
        v-if="currentLevel === 'weekly' || currentLevel === 'daily'"
        @click="setLevel('weekly')"
        class="cursor-pointer hover:underline"
      >
        Week {{ selectedWeek?.label || selectedWeek?.week || '–' }}
      </span>
      <span v-if="currentLevel === 'daily'"> > {{ selectedDate }}</span>
    </div>

    <!-- Conditional rendering based on currentLevel -->
    <div v-if="currentLevel === 'monthly'">
      <MonthlySummary :weeklyStats="weeklyStats" @selectWeek="goToWeek" />
    </div>

    <div v-else-if="currentLevel === 'weekly'">
      <WeeklySummary :dailyStats="dailyStats" @selectDate="goToDate" />
    </div>

    <div v-else-if="currentLevel === 'daily'">
      <DailySummary :dailyData="dailyData" />
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import MonthlySummary from '@/components/summary/MonthlySummary.vue'
import WeeklySummary from '@/components/summary/WeeklySummary.vue'
import DailySummary from '@/components/summary/DailySummary.vue'

const currentLevel = ref('monthly')
const selectedWeek = ref(null)
const selectedDate = ref(null)

const weeklyStats = ref([
  { week: 'Week 1', deliveries: 120 },
  { week: 'Week 2', deliveries: 95 },
  { week: 'Week 3', deliveries: 60 },
  { week: 'Week 4', deliveries: 110 }
])

const dailyStats = ref([])
const dailyData = ref({})

function setLevel(level) {
  currentLevel.value = level
}

function goToWeek(week) {
  selectedWeek.value = week
  currentLevel.value = 'weekly'

  dailyStats.value = [
    {
      date: '2025-05-12',
      deliveries: 15,
      workers: [
        { name: 'Alice', deliveries: 6, avgTime: 20 },
        { name: 'Bob', deliveries: 9, avgTime: 18 }
      ]
    },
    {
      date: '2025-05-13',
      deliveries: 20,
      workers: [
        { name: 'Alice', deliveries: 10, avgTime: 22 },
        { name: 'Bob', deliveries: 10, avgTime: 19 }
      ]
    }
  ]
}

function goToDate(date) {
  selectedDate.value = date
  currentLevel.value = 'daily'

  const selectedDay = dailyStats.value.find(d => d.date === date)
  const statusCount = { Completed: 0, Pending: 0, Late: 0 }

  const deliveries = [
    { id: 201, worker: 'Alice', time: '09:00', status: 'Completed' },
    { id: 202, worker: 'Bob', time: '10:15', status: 'Late' }
  ]

  deliveries.forEach(d => {
    if (statusCount[d.status] !== undefined) statusCount[d.status]++
  })

  dailyData.value = {
    date,
    deliveries,
    workers: selectedDay?.workers || [],
    statusBreakdown: Object.entries(statusCount).map(([label, value]) => ({ label, value }))
  }
}
</script>

<style scoped>
.cursor-pointer {
  cursor: pointer;
}
</style>
