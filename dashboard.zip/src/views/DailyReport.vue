<template>
  <div class="p-6 space-y-6">
    <!-- Header -->
    <div class="flex items-center justify-between">
      <h1 class="text-2xl font-bold text-white">
        📅 Daily Report – {{ formattedDate }}
      </h1>
      <button class="text-sm bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-md">
        Switch Date
      </button>
    </div>

    <!-- Metrics Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      <MetricCard title="Total Deliveries" :value="totalDeliveries + ' pcs'" />
      <MetricCard title="Dishwashing Total" :value="dishwashingTotal + ' pcs'" />
      <MetricCard title="Steel Nails Total" :value="steelTotal + ' pcs'" />
      <MetricCard title="Single-Walled Total" :value="singleWalledTotal + ' pcs'" />
      <MetricCard title="Double-Walled Total" :value="doubleWalledTotal + ' pcs'" />
      <MetricCard title="Square Pads Sold" :value="accessoryTotal + ' kg'" />
    </div>

    <!-- Charts -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <DeliveryBarChart :data="barChartData" />
      <ProductPieChart :data="pieChartData" />
    </div>

    <!-- Missing Workers -->
    <div
      v-if="missingWorkers.length"
      class="bg-red-500/10 text-red-300 border border-red-400 rounded-lg p-4"
    >
      <strong>⚠ Missing Logs:</strong>
      <ul class="mt-1 list-disc list-inside">
        <li v-for="worker in missingWorkers" :key="worker">{{ worker }}</li>
      </ul>
    </div>

    <!-- Delivery Table -->
    <DeliveryTable :deliveries="deliveries" />
  </div>
</template>

<script>
import MetricCard from '../components/MetricCard.vue';
import DeliveryBarChart from '../components/BarChart.vue';
import ProductPieChart from '../components/ProductPieChart.vue';
import DeliveryTable from '../components/DeliveryTable.vue';

export default {
  components: {
    MetricCard,
    DeliveryBarChart,
    ProductPieChart,
    DeliveryTable,
  },
  data() {
    return {
      deliveries: [],
      knownWorkers: ['Mhar', 'Joper', 'Bong'],
      deliveryDate: '',
    };
  },
  computed: {
    totalDeliveries() {
      return this.deliveries.reduce((sum, d) => sum + d.quantityDelivered, 0);
    },
    dishwashingTotal() {
      return this.deliveries
        .filter(d => d.client === 'Dishwashing')
        .reduce((sum, d) => sum + d.quantityDelivered, 0);
    },
    steelTotal() {
      return this.deliveries
        .filter(d => d.client === 'Steel Nails')
        .reduce((sum, d) => sum + d.quantityDelivered, 0);
    },
    singleWalledTotal() {
        const types = ['Gallon', '1.5L', '1L', '330mL'];
        return this.deliveries
          .filter(d => types.includes(d.productType))
          .reduce((sum, d) => sum + d.quantityDelivered, 0);
      },
      doubleWalledTotal() {
        const types = ['5"', '6"', '6.5"'];
        return this.deliveries
          .filter(d => types.includes(d.productType))
          .reduce((sum, d) => sum + d.quantityDelivered, 0);
      },
      accessoryTotal() {
        return this.deliveries
          .filter(d => d.productType === 'Square Pads')
          .reduce((sum, d) => sum + d.quantityDelivered, 0);
      },
    singleWalledTotal() {
        const types = ['Gallon', '1.5L', '1L', '330mL'];
        return this.deliveries
          .filter(d => types.includes(d.productType))
          .reduce((sum, d) => sum + d.quantityDelivered, 0);
      },
      doubleWalledTotal() {
        const types = ['5"', '6"', '6.5"'];
        return this.deliveries
          .filter(d => types.includes(d.productType))
          .reduce((sum, d) => sum + d.quantityDelivered, 0);
      },
      accessoryTotal() {
        return this.deliveries
          .filter(d => d.productType === 'Square Pads')
          .reduce((sum, d) => sum + d.quantityDelivered, 0);
      },

    missingWorkers() {
      const logged = this.deliveries.map(d => d.workerName);
      return this.knownWorkers.filter(w => !logged.includes(w));
    },
    barChartData() {
      const map = {};
      this.deliveries.forEach(d => {
        map[d.workerName] = (map[d.workerName] || 0) + d.quantityDelivered;
      });
      return {
        labels: Object.keys(map),
        datasets: [
          {
            label: 'Total Deliveries',
            data: Object.values(map),
            backgroundColor: 'rgba(59, 130, 246, 0.5)',
            borderColor: 'rgba(59, 130, 246, 1)',
            borderWidth: 1,
          },
        ],
      };
    },
    pieChartData() {
      const typeMap = {};
      this.deliveries.forEach(d => {
        typeMap[d.productType] = (typeMap[d.productType] || 0) + d.quantityDelivered;
      });
      return {
        labels: Object.keys(typeMap),
        datasets: [
          {
            data: Object.values(typeMap),
            backgroundColor: ['#60a5fa', '#f472b6', '#fbbf24', '#34d399'],
          },
        ],
      };
    },
    formattedDate() {
      const d = new Date();
      return d.toLocaleDateString(undefined, {
        weekday: 'long',
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });
    },
  },
  mounted() {
    this.deliveryDate = this.getCurrentDate();
    const saved = localStorage.getItem('deliveries');
    if (saved) this.deliveries = JSON.parse(saved);
  },
  watch: {
    deliveries: {
      handler(newVal) {
        localStorage.setItem('deliveries', JSON.stringify(newVal));
      },
      deep: true,
    },
  },
  methods: {
    getCurrentDate() {
      const today = new Date();
      const year = today.getFullYear();
      const month = String(today.getMonth() + 1).padStart(2, '0');
      const day = String(today.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    },
  },
};
</script>
