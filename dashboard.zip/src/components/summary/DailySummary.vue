<template>
  <div class="space-y-6">
    <h2 class="text-xl font-bold">Daily Summary – {{ dailyData.date }}</h2>

    <!-- Charts Component -->
    <SummaryCharts :mode="'daily'" :data="dailyData" />

    <!-- Delivery Logs -->
    <div class="bg-white rounded-xl shadow p-4">
      <h3 class="text-md font-semibold mb-2">Delivery Log</h3>
      <table class="w-full text-sm">
        <thead>
          <tr class="text-left border-b">
            <th class="py-2">Worker</th>
            <th class="py-2">Delivery ID</th>
            <th class="py-2">Time</th>
            <th class="py-2">Status</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="entry in dailyData.deliveries"
            :key="entry.id"
            class="border-b"
          >
            <td class="py-2">{{ entry.worker }}</td>
            <td class="py-2">#{{ entry.id }}</td>
            <td class="py-2">{{ entry.time }}</td>
            <td class="py-2">
              <span :class="statusClass(entry.status)">{{ entry.status }}</span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import SummaryCharts from '@/components/SummaryCharts.vue'

const props = defineProps({
  dailyData: Object
})

function statusClass(status) {
  switch (status) {
    case 'Completed': return 'text-green-600 font-semibold'
    case 'Pending': return 'text-yellow-600 font-semibold'
    case 'Late': return 'text-red-600 font-semibold'
    default: return 'text-gray-600'
  }
}
</script>