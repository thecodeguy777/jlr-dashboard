<template>
  <div class="space-y-6">
    <!-- Deliveries by Timeframe -->
    <div class="bg-white rounded-xl shadow p-4">
      <h3 class="text-md font-semibold mb-2">
        <span v-if="mode === 'daily'">Deliveries per Worker (Today)</span>
        <span v-else-if="mode === 'weekly'">Deliveries per Day (This Week)</span>
        <span v-else-if="mode === 'monthly'">Deliveries per Week (This Month)</span>
      </h3>
      <BarChart :data="barChartData" />
    </div>

    <!-- Status Breakdown -->
    <div class="bg-white rounded-xl shadow p-4">
      <h3 class="text-md font-semibold mb-2">Status Breakdown</h3>
      <PieChart :data="statusChartData" />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import BarChart from '@/components/BarChart.vue'
import PieChart from '@/components/PieChart.vue'

const props = defineProps({
  mode: {
    type: String,
    required: true
  },
  data: {
    type: Object,
    default: () => ({})
  }
})


const barChartData = computed(() => {
  if (!props.data) return {}

  if (props.mode === 'monthly') {
    const labels = props.data.map(item => item.week || item.label)
    const values = props.data.map(item => item.deliveries)

    return {
      labels,
      datasets: [
        {
          label: 'Deliveries',
          backgroundColor: '#3b82f6',
          data: values
        }
      ]
    }
  }

  if (props.mode === 'weekly') {
    const labels = props.data.map(item => item.date)
    const values = props.data.map(item => item.deliveries)

    return {
      labels,
      datasets: [
        {
          label: 'Deliveries',
          backgroundColor: '#3b82f6',
          data: values
        }
      ]
    }
  }

  if (props.mode === 'daily') {
    const labels = props.data?.workers?.map(w => w.worker || w.name)
    const values = props.data?.workers?.map(w => w.deliveries)

    return {
      labels,
      datasets: [
        {
          label: 'Deliveries',
          backgroundColor: '#3b82f6',
          data: values
        }
      ]
    }
  }

  return {}
})

const statusChartData = computed(() => {
  if (props.mode === 'daily') {
    const counts = { Completed: 0, Pending: 0, Late: 0 }
    props.data?.deliveries?.forEach(d => {
      if (counts[d.status] !== undefined) counts[d.status]++
    })
    return Object.entries(counts).map(([label, value]) => ({ label, value }))
  }

  const breakdown = props.data?.statusBreakdown
  if (!Array.isArray(breakdown)) return []
  return breakdown
})

</script>
