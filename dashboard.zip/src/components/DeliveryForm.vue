<template>
  <div
   v-if="localForm && typeof localForm === 'object'"
    id="delivery-form"
    :class="[
      'backdrop-blur-md p-6 rounded-2xl shadow-md border transition-all',
      editMode ? 'bg-yellow-100/10 border-yellow-400' : 'bg-white/10 border-white/10'
    ]"
  >
    <h2 class="text-2xl font-bold mb-4 border-b border-gray-600 pb-2">
      {{ editMode && localForm.workerName ? `Edit Delivery for ${localForm.workerName}` : 'Log New Delivery' }}
    </h2>

    <!-- Worker Name -->
    <div class="mb-4 relative">
      <label for="worker_name" class="block text-sm font-medium text-gray-300">Worker Name</label>

      <input
        v-if="editMode"
        :value="localForm.workerName"
        id="worker_name"
        disabled
        class="mt-1 block w-full p-2 bg-gray-600 text-white border border-gray-600 rounded-md opacity-70 cursor-not-allowed"
      />

      <div v-else>
        <input
          v-model="searchTerm"
          @input="showSuggestions = true"
          @blur="hideSuggestions"
          type="text"
          id="worker_name"
          class="mt-1 block w-full p-2 bg-gray-700 text-white border border-gray-600 rounded-md"
          placeholder="Start typing a name..."
        />
        <ul
          v-if="showSuggestions && filteredWorkers.length"
          class="absolute z-10 w-full bg-gray-800 border border-gray-600 rounded-md mt-1"
        >
          <li
            v-for="(worker, index) in filteredWorkers"
            :key="index"
            @mousedown.prevent="selectWorker(worker)"
            class="px-4 py-2 cursor-pointer hover:bg-gray-700"
          >
            {{ worker }}
          </li>
        </ul>
      </div>
    </div>

    <!-- Product Type -->
    <div class="mb-4">
      <label for="product_type" class="block text-sm font-medium text-gray-300">Product Type</label>
      <select
        v-model="localForm.productType"
        id="product_type"
        class="mt-1 block w-full p-2 bg-gray-700 text-white border border-gray-600 rounded-md"
      >
        <option value="1L">1L</option>
        <option value="1.5L">1.5L</option>
        <option value="Gallon">Gallon</option>
        <option value="330mL">330mL</option>
        <option value='5"'>5"</option>
        <option value='6"'>6"</option>
        <option value='6.5"'>6.5"</option>
        <option value="Square Pads">Square Pads</option>
        <option value="Liner">Liner</option>
      </select>
    </div>

    <!-- Quantity -->
    <div class="mb-4">
      <label for="quantity_delivered" class="block text-sm font-medium text-gray-300">Quantity Delivered</label>
      <input
        v-model.number="localForm.quantityDelivered"
        type="number"
        id="quantity_delivered"
        class="mt-1 block w-full p-2 bg-gray-700 text-white border border-gray-600 rounded-md"
      />
    </div>

    <!-- Delivery Date -->
    <div class="mb-4">
      <label for="delivery_date" class="block text-sm font-medium text-gray-300">Delivery Date</label>
      <input
        v-model="localForm.deliveryDate"
        type="date"
        id="delivery_date"
        class="mt-1 block w-full p-2 bg-gray-700 text-white border border-gray-600 rounded-md"
      />
    </div>

    <!-- Notes -->
    <div class="mb-4">
      <label for="notes" class="block text-sm font-medium text-gray-300">Notes</label>
      <textarea
        v-model="localForm.notes"
        id="notes"
        class="mt-1 block w-full p-2 bg-gray-700 text-white border border-gray-600 rounded-md"
      ></textarea>
    </div>

    <!-- Buttons -->
    <div class="flex gap-2">
      <button
        @click="handleSubmit"
        class="flex-1 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
      >
        {{ editMode ? 'Update Delivery' : 'Log Delivery' }}
      </button>
      <button
        v-if="editMode"
        @click="$emit('cancel-edit')"
        class="flex-1 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
      >
        Cancel
      </button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    formData: {
      type: Object,
      required: true,
    },
    editMode: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      localForm: JSON.parse(JSON.stringify(this.formData)),
      knownWorkers: ['Bong', 'Joper', 'Mhar'],
      searchTerm: this.formData.workerName || '',
      showSuggestions: false,
    };
  },
  watch: {
    formData: {
      handler(newVal) {
        this.localForm = JSON.parse(JSON.stringify(newVal));
        this.searchTerm = newVal.workerName || '';
      },
      deep: true,
      immediate: true,
    },
  },
  computed: {
    filteredWorkers() {
      const term = this.searchTerm.toLowerCase();
      return this.knownWorkers.filter(w =>
        w.toLowerCase().includes(term)
      );
    },
  },
  methods: {
    selectWorker(name) {
      this.searchTerm = name;
      this.localForm.workerName = name;
      this.showSuggestions = false;
    },
    hideSuggestions() {
      setTimeout(() => {
        this.showSuggestions = false;
      }, 100);
    },
    handleSubmit() {
      if (!this.editMode && !this.searchTerm.trim()) {
        alert('Please enter a worker name.');
        return;
      }

      if (!this.localForm.productType) {
        alert('Please select a product type.');
        return;
      }

      if (!this.editMode) {
        this.localForm.workerName = this.searchTerm.trim();
      }

      this.$emit('submit', { ...this.localForm });
    },
  },
};
</script>
