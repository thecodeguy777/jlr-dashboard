<template>
  <div class="space-y-6">
    <h2 class="text-xl font-bold">Monthly Summary</h2>

    <!-- Bar chart: Deliveries per Week -->
    <div class="bg-white rounded-xl shadow p-4">
      <h3 class="text-md font-semibold mb-2">Deliveries per Week</h3>
      <!-- Replace with actual chart component -->
      <BarChart :data="weeklyStats" xKey="week" yKey="deliveries" />
    </div>

    <!-- Top Workers This Month -->
    <div class="bg-white rounded-xl shadow p-4">
      <h3 class="text-md font-semibold mb-2">Top Workers</h3>
      <ul>
        <li v-for="(worker, index) in topWorkers" :key="index">
          {{ index + 1 }}. {{ worker.name }} – {{ worker.deliveries }} deliveries
        </li>
      </ul>
    </div>

    <!-- Drill into a specific week -->
    <div class="bg-white rounded-xl shadow p-4">
      <h3 class="text-md font-semibold mb-2">Select Week</h3>
      <ul class="flex gap-4">
        <li
          v-for="week in weeklyStats"
          :key="week.id"
          class="cursor-pointer hover:underline text-blue-500"
          @click="$emit('selectWeek', week)"
        >
          Week {{ week.label || week.id }}
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup>
import BarChart from '@/components/BarChart.vue' // adjust path if needed
import { computed } from 'vue'

const props = defineProps({
  weeklyStats: Array
})

// Simulated top 3 workers — you’ll want to compute this from your real data
const topWorkers = computed(() => {
  const deliveriesByWorker = {}

  props.weeklyStats.forEach(week => {
    week.workers?.forEach(worker => {
      deliveriesByWorker[worker.name] = (deliveriesByWorker[worker.name] || 0) + worker.deliveries
    })
  })

  return Object.entries(deliveriesByWorker)
    .map(([name, deliveries]) => ({ name, deliveries }))
    .sort((a, b) => b.deliveries - a.deliveries)
    .slice(0, 3)
})
</script>
